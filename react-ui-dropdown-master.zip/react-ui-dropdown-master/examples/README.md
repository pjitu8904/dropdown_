# Examples for React UI Dropdown

## How to use

````
$ cd examples
````

````
$ npm install
````

Set enviroment variable

````
$ EXAMPLE_NAME=simple
````
EXAMPLE_NAME can be name of directory in /examples.

````
$ npm run start
````


By default, start in development mode (with hot reload).
If you want a production mode (support IE8+), set enviroment variable NODE_ENV
````
$ NODE_ENV=production
````
